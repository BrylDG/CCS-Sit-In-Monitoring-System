<?php
    echo "Welcome to the dashboard!";
?>