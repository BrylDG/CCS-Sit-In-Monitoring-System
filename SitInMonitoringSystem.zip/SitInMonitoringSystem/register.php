<?php
include ("dbfunction.php"); 

// Ensure the database connection is set
if (!isset($conn)) {
    die("Database connection error.");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (
        isset($_POST['idNo'], $_POST['firstName'], $_POST['lastName'], $_POST['middleName'], 
        $_POST['course'], $_POST['yearLevel'], $_POST['email'], $_POST['username'], 
        $_POST['password'], $_POST['confirm_password'])
    ) {
        $idNo = mysqli_real_escape_string($conn, $_POST['idNo']);
        $firstName = mysqli_real_escape_string($conn, $_POST['firstName']);
        $lastName = mysqli_real_escape_string($conn, $_POST['lastName']);
        $middleName = mysqli_real_escape_string($conn, $_POST['middleName']);
        $course = mysqli_real_escape_string($conn, $_POST['course']);
        $yearLevel = mysqli_real_escape_string($conn, $_POST['yearLevel']);
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        $username = mysqli_real_escape_string($conn, $_POST['username']);
        $password = $_POST['password'];
        $confirm_password = $_POST['confirm_password'];

        // Password Confirmation Check
        if ($password !== $confirm_password) {
            echo "Passwords do not match.";
            exit;
        }

        // Hash the password for security
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Insert into the database
        $query = "INSERT INTO users (idNo, firstName, lastName, middleName, course, yearLevel, emailAddress, username, password) 
                  VALUES ('$idNo', '$firstName', '$lastName', '$middleName', '$course', '$yearLevel', '$email', '$username', '$hashed_password')";

        $result = mysqli_query($conn, $query);

        if ($result) {
            echo "Registration Successful";
        } else {
            echo "Registration Failed: " . mysqli_error($conn);
        }
    } else {
        echo "All fields are required.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="stylesheet" href="registerStyles.css">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <title>Register Page</title>
</head>
<body>
    <div id="form-container">
        <h2>CSS Sit-In Monitoring System</h2>
        <form action="" method="POST">
            <div id="FirstDivision">
                <div class="division">
                    <label for="idNo">ID Number</label>
                    <input type="text" name="idNo" required>
                </div>
                <div class="division">
                    <label for="firstName">First Name</label>
                    <input type="text" name="firstName" required>
                </div>
            </div>
            <div id="SecondDivision">
                <div class="division">
                    <label for="lastName">Last Name</label>
                    <input type="text" name="lastName" required>
                </div>
                <div class="division">
                    <label for="middleName">Middle Name</label>
                    <input type="text" name="middleName" required>
                </div>
            </div>
            <div id="ThirdDivision">
                <div class="division">
                    <label for="course">Course</label>
                    <input type="text" name="course" required>
                </div>
                <div class="division">
                    <label for="yearLevel">Year Level</label>
                    <input type="number" name="yearLevel" required>
                </div>
            </div>
            <div>
                <div class="division">
                    <label for="email">Email</label>
                    <input type="email" name="email" required>
                </div>
                <div class="division">
                    <label for="username">Username</label>
                    <input type="text" name="username" required>
                </div>
            </div>
            <div id="FourthDivision">
                <div class="division">
                    <label for="password">Password</label>
                    <input type="password" name="password" required>
                </div>
                <div class="division">
                    <label for="confirm_password">Confirm Password</label>
                    <input type="password" name="confirm_password" required>
                </div>
            </div>
            <button type="submit">Register</button>
        </form>
        <label>Already have an account? <a href="login.php">Login here.</a></label>
    </div>
</body>
</html>
