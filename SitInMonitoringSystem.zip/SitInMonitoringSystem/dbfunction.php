<?php

    $db_server = "localhost";
    $db_username = "root";
    $db_password = "";
    $db_name = "sitinmanagementsystem";
    $conn = mysqli_connect($db_server, $db_username, $db_password, $db_name);
?>