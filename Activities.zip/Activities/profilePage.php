<?php
session_start();
include("dbfunction.php");

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$username = $_SESSION['username'];

// Handle Profile Update
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $newIdNo = $_POST['idNo'];
    $newFirstName = $_POST['firstName'];
    $newLastName = $_POST['lastName'];
    $newMiddleName = $_POST['middleName'];
    $newCourse = $_POST['course'];
    $newYearLevel = $_POST['yearLevel'];
    $newEmail = $_POST['email'];
    $newPassword = $_POST['password'];

    // Start building the update query
    $updateQuery = "UPDATE users SET idNo = ?, firstName = ?, lastName = ?, middleName = ?, course = ?, yearLevel = ?, emailAddress = ?";
    $queryParams = [$newIdNo, $newFirstName, $newLastName, $newMiddleName, $newCourse, $newYearLevel, $newEmail];
    $paramTypes = "sssssss";

    // If a new password is provided, hash it and add to query
    if (!empty($newPassword)) {
        $updateQuery .= ", password = ?";
        $queryParams[] = $newPassword;
        $paramTypes .= "s";
    }

    // Finalize query
    $updateQuery .= " WHERE username = ?";
    $queryParams[] = $username;
    $paramTypes .= "s";

    // Prepare and execute statement
    $updateStmt = mysqli_prepare($conn, $updateQuery);
    mysqli_stmt_bind_param($updateStmt, $paramTypes, ...$queryParams);

    if (mysqli_stmt_execute($updateStmt)) {
        $_SESSION['success_message'] = "Profile updated successfully!";
        header("Location: profilePage.php"); // Redirect to refresh profile page
        exit();
    } else {
        $_SESSION['error_message'] = "Failed to update profile.";
    }
}

// Fetch Updated Profile
$query = "SELECT idNo, firstName, lastName, middleName, course, yearLevel, emailAddress, username, password FROM users WHERE username = ?";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "s", $username);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if ($result && mysqli_num_rows($result) > 0) {
    $user = mysqli_fetch_assoc($result);
} else {
    die("User not found.");
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="stylesheet" href="css/profileStyles.css">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <title>View Profile</title>
</head>
<body>
    <div class="profileDiv">
        <h1>Profile Page</h1>
        <div class="formContainer">
            <label for="idNo">ID Number:</label>
            <input class="profileInput" type="text" id="idNo" value="<?php echo htmlspecialchars($user['idNo']); ?>" readonly>
            
            <label for="firstName">First Name:</label>
            <input class="profileInput" type="text" id="firstName" value="<?php echo htmlspecialchars($user['firstName']); ?>" readonly>
            
            <label for="lastName">Last Name:</label>
            <input class="profileInput" type="text" id="lastName" value="<?php echo htmlspecialchars($user['lastName']); ?>" readonly>
            
            <label for="middleName">Middle Name:</label>
            <input class="profileInput" type="text" id="middleName" value="<?php echo htmlspecialchars($user['middleName']); ?>" readonly>
            
            <label for="course">Course:</label>
            <input class="profileInput" type="text" id="course" value="<?php echo htmlspecialchars($user['course']); ?>" readonly>
            
            <label for="yearLevel">Year Level:</label>
            <input class="profileInput" type="text" id="yearLevel" value="<?php echo htmlspecialchars($user['yearLevel']); ?>" readonly>
            
            <label for="email">Email:</label>
            <input class="profileInput" type="email" id="email" value="<?php echo htmlspecialchars($user['emailAddress']); ?>" readonly>
            
            <label for="username">Username:</label>
            <input class="profileInput" type="text" id="username" value="<?php echo htmlspecialchars($user['username']); ?>" readonly>
        </div>
        <button onclick="openPopup()" id="editButton">Edit</button>
    </div>

    <div class="popup" id="editPopup">
        <div class="popup-content">
            <span class="close-btn" onclick="closePopup()">&times;</span>
            <h2>Edit Profile</h2>
            <form action="profilePage.php" method="POST">
                <input type="hidden" name="username" value="<?php echo htmlspecialchars($user['username']); ?>">
                
                <label for="idNo">ID Number:</label>
                <input class="editInput" type="text" name="idNo" value="<?php echo htmlspecialchars($user['idNo']); ?>" required>
                
                <label for="firstName">First Name:</label>
                <input class="editInput" type="text" name="firstName" value="<?php echo htmlspecialchars($user['firstName']); ?>" required>
                
                <label for="lastName">Last Name:</label>
                <input class="editInput" type="text" name="lastName" value="<?php echo htmlspecialchars($user['lastName']); ?>" required>
                
                <label for="middleName">Middle Name:</label>
                <input class="editInput" type="text" name="middleName" value="<?php echo htmlspecialchars($user['middleName']); ?>">
                
                <label for="course">Course:</label>
                <input class="editInput" type="text" name="course" value="<?php echo htmlspecialchars($user['course']); ?>" required>
                
                <label for="yearLevel">Year Level:</label>
                <input class="editInput" type="text" name="yearLevel" value="<?php echo htmlspecialchars($user['yearLevel']); ?>" required>
                
                <label for="email">Email:</label>
                <input class="editInput" type="email" name="email" value="<?php echo htmlspecialchars($user['emailAddress']); ?>" required>
                
                <label for="password">Password:</label>
                <input class="editInput" type="password" name="password" value="<?php echo htmlspecialchars($user['password']); ?>" required>

                
                <button type="submit" id="updateButton">Update</button>
            </form>
        </div>
    </div>

    <script>
            <?php if (isset($_SESSION['success_message'])): ?>
        alert("<?php echo $_SESSION['success_message']; ?>");
        window.location.href = "dashboard.php"; // Redirect back to profile
    <?php unset($_SESSION['success_message']); endif; ?>
    </script>
</body>
</html>
