<?php
session_start();
include("dbfunction.php");

if (!$conn) {
   die("Database connection failed: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']); // Sanitize input

    $query = "SELECT * FROM users WHERE username = '$username'";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $user = mysqli_fetch_assoc($result);

        // Directly compare plain text password (Not recommended for security)
        if ($password === $user['password']) {
            $_SESSION['username'] = $user['username'];
            echo '<script>
                    alert("Login Successful");
                    window.location.href="dashboard.php";
                </script>';
            exit();
        } else {
            echo '<script>alert("Invalid password"); window.history.back();</script>';
        }
    } else {
        echo '<script>alert("Invalid username"); window.history.back();</script>';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/loginStyles.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <title>Login Page</title>
</head>
<body>
    <div>
        <div id="top">
            <div id="topinside">
                <img src="images/CCS_LOGO.png" alt="logo" id="logo">
                <h2>CSS Sit-In Monitoring System</h2>
            </div>
            <hr>
        </div>

        <form action="" method="POST">
            <label for="username">Username</label>
            <input type="text" name="username" id="username" required>
            <label for="password">Password</label>
            <input type="password" name="password" id="password" required>
            <?php if (isset($error)) { echo "<p style='color: red; font-size: 10px;'>$error</p>"; } ?>
            <button type="submit">Login</button>
        </form>
        <label id="register">Don't have an account? <a href="register.php">Register here.</a></label>
    </div>
</body>
</html>
