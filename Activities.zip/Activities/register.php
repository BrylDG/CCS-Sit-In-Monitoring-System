<?php
include ("dbfunction.php"); 

if (!isset($conn)) {
    die("Database connection error.");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (
        isset($_POST['idNo'], $_POST['firstName'], $_POST['lastName'], $_POST['middleName'], 
        $_POST['course'], $_POST['yearLevel'], $_POST['email'], $_POST['username'], 
        $_POST['password'], $_POST['confirm_password'])
    ) {
        $idNo = mysqli_real_escape_string($conn, $_POST['idNo']);
        $firstName = mysqli_real_escape_string($conn, $_POST['firstName']);
        $lastName = mysqli_real_escape_string($conn, $_POST['lastName']);
        $middleName = mysqli_real_escape_string($conn, $_POST['middleName']);
        $course = mysqli_real_escape_string($conn, $_POST['course']);
        $yearLevel = mysqli_real_escape_string($conn, $_POST['yearLevel']);
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        $username = mysqli_real_escape_string($conn, $_POST['username']);
        $password = $_POST['password'];
        $confirm_password = $_POST['confirm_password'];

        if ($password !== $confirm_password) {
            echo "Passwords do not match.";
            exit;
        }

        $query = "INSERT INTO users (idNo, firstName, lastName, middleName, course, yearLevel, emailAddress, username, password) 
                  VALUES ('$idNo', '$firstName', '$lastName', '$middleName', '$course', '$yearLevel', '$email', '$username', '$password')";

        $result = mysqli_query($conn, $query);

        if ($result) {
            echo '<script>alert("Registration Successful")</script>';
            header("Location: login.php");
            exit();
        } else {
            echo '<script>alert("Registration Failed: " . mysqli_error($conn))</script>';
        }
    } else {
        echo '<script>alert("All fields are required.")</script>';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="stylesheet" href="css/registerStyles.css">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <title>Register Page</title>
</head>
<body>
    <div id="form-container">
        <div id="top">
            <div id="topinside">
                <img src="images/CCS_LOGO.png" alt="logo" id="logo">
                <h2>CSS Sit-In Monitoring System</h2>
            </div>
            <hr>
        </div>
        <form action="" method="POST">
            <div id="FirstDivision">
                <div class="division">
                    <label for="idNo">ID Number</label>
                    <input type="number" name="idNo" required>
                </div>
                <div class="division">
                    <label for="firstName">First Name</label>
                    <input type="text" name="firstName" required>
                </div>
            </div>
            <div id="SecondDivision">
                <div class="division">
                    <label for="lastName">Last Name</label>
                    <input type="text" name="lastName" required>
                </div>
                <div class="division">
                    <label for="middleName">Middle Name</label>
                    <input type="text" name="middleName">
                </div>
            </div>
            <div id="ThirdDivision">
                <div class="division">
                    <label for="course">Course</label>
                    <select name="course" id="course" class="custom-dropdown">
                        <option value="" disabled selected style="display: none;">Select Course</option>
                        <option value="BSIT">BSIT</option>
                        <option value="BSCS">BSCS</option>
                        <option value="BEEd">BEEd</option>
                        <option value="BSEd">BSEd</option>
                        <option value="BSBA">BSBA</option>
                        <option value="BSME">BSME</option>
                    </select>
                </div>
                <div class="division">
                    <label for="yearLevel">Year Level</label>
                    <select name="yearLevel" id="yearLevel" class="custom-dropdown">
                        <option value="" disabled selected style="display: none;">Select Year Level</option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                    </select>
                </div>
            </div>
            <div>
                <div class="division">
                    <label for="email">Email</label>
                    <input type="email" name="email" required style="width: 93%;">
                </div>
                <div class="division">
                    <label for="username">Username</label>
                    <input type="text" name="username" required style="width: 93%;">
                </div>
            </div>
            <div id="FourthDivision">
                <div class="division">
                    <label for="password">Password</label>
                    <input type="password" name="password" required>
                </div>
                <div class="division">
                    <label for="confirm_password">Confirm Password</label>
                    <input type="password" name="confirm_password" required>
                </div>
            </div>
            <button type="submit" style="margin-top: 5%;">Register</button>
        </form>
        <label id="login">Already have an account? <a href="login.php">Login here.</a></label>
    </div>
</body>
</html>
