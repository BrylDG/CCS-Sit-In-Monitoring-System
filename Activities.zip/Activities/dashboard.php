<?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        session_unset();
        session_destroy();
        header("Location: login.php");
        exit();
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/dashboardStyles.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <title>Dashboard</title>
</head>
<body>
    <div id="Main-div">
        <div id="Side-bar">
            <div id="Profile-section">
                <a href="#" id="ViewProfile"><img src="images/profileIcon.jpg" alt="User-profile" id="User-Profile"></a> <!-- if clicked, route to profile -->
                <label for="" id="User-name">Bryl</label>
            </div>

            <div id="Page-section">
                <a href="#" id="Dashboard" class="selection">
                    <img src="images/advertising.png" alt="Dashboard-icon" id="Dashboard-icon" class="icon">
                    Announcements
                </a>
                <a href="#" id="History" class="selection">
                    <img src="images/history.png" alt="History-icon" id="History-icon" class="icon">
                    History
                </a>
                <a href="#" id="Reservation" class="selection">
                    <img src="images/booking.png" alt="Booking-icon" id="Booking-icon" class="icon">
                    Reservation
                </a>
            </div>

            <form action="" method="POST" id="logout-button">
                <input type="submit" value="Log Out" id="logoutbtn">
            </form>
        </div>
        <div id="Main-content">
            <div id="Announcement-div">
                <h1>Announcements</h1>
            </div>

            <div id="RulesReg-div">
                <div id=RulesReg-Top>
                    <h2>University of Cebu</h2>
                    <h3>COLLEGE OF INFORMATION AND COMPUTER STUDIES</h3>
                </div>
                <div id="Rules-Div">
                    <div id="Rules-Top">
                        <h1>Sit-in Rules</h1>
                    </div>
                    <div id="Rules-Body">
                    <ul>
                        <li>First Offense - The Head or the Dean or OIC recommends to the Guidance Center for a suspension from classes for each offender.</li>
                        <li>Second and Subsequent Offenses - A recommendation for a heavier sanction will be endorsed to the Guidance Center.</li>
                    </ul>

                    </div>
                </div>
                <div id="Regulations-Div">
                    <div id="Regulations-Top">
                        <h1>Lab Rules & Regulations</h1>
                    </div>
                    <div id="Regulations-Body">
                        <h3>LABORATORY RULES AND REGULATIONS</h3>
                        <p>To avoid embarrassment and maintain camaraderie with your friends and superiors at our laboratories, please observe the following:</p>
                        <p>1. Maintain silence, proper decorum, and discipline inside the laboratory. Mobile phones, walkmans, and other personal pieces of equipment must be switched off.</p>
                        <p>2. Games are not allowed inside the lab. This includes computer-related games, card games, and other games that may disturb the operation of the lab.</p>
                        <p>3. Surfing the Internet is allowed only with the permission of the instructor. Downloading and installing of software are strictly prohibited.</p>
                        <p>4. Getting access to other websites not related to the course (especially pornographic and illicit sites) is strictly prohibited.</p>
                        <p>5. Deleting computer files and changing the set-up of the computer is a major offense.</p>
                        <p>6. Observe computer time usage carefully. A fifteen-minute allowance is given for each use. Otherwise, the unit will be given to those who wish to "sit-in."</p>
                        <p>7. Observe proper decorum while inside the laboratory.</p>
                        <ul>
                            <li>Do not get inside the lab unless the instructor is present.</li>
                            <li>All bags, knapsacks, and the likes must be deposited at the counter.</li>
                            <li>Follow the seating arrangement of your instructor.</li>
                            <li>At the end of class, all software programs must be closed.</li>
                            <li>Return all chairs to their proper places after using.</li>
                        </ul>
                        <p>8. Chewing gum, eating, drinking, smoking, and other forms of vandalism are prohibited inside the lab.</p>
                        <p>9. Anyone causing a continual disturbance will be asked to leave the lab. Acts or gestures offensive to the members of the community, including public display of physical intimacy, are not tolerated.</p>
                        <p>10. Persons exhibiting hostile or threatening behavior such as yelling, swearing, or disregarding requests made by lab personnel will be asked to leave the lab.</p>
                        <p>11. For serious offenses, the lab personnel may call the Civil Security Office (CSU) for assistance.</p>
                        <p>12. Any technical problem or difficulty must be addressed to the laboratory supervisor, student assistant, or instructor immediately.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const originalContent = document.getElementById("Main-content").innerHTML;
            const links = document.querySelectorAll(".selection");

            function setActiveLink(clickedLink) {
                links.forEach(link => link.classList.remove("active"));
                clickedLink.classList.add("active");
            }

            document.getElementById("ViewProfile").addEventListener("click", function(event) {
                event.preventDefault();
                fetch('./profilePage.php')
                .then(response => response.text())
                .then(data => {
                    document.getElementById("Main-content").innerHTML = data;
                })
                .catch(error => console.error('Error fetching content:', error));
            });

            document.getElementById("Dashboard").addEventListener("click", function(event) {
                event.preventDefault();
                document.getElementById("Main-content").innerHTML = originalContent;
                setActiveLink(this);
            });

            document.getElementById("History").addEventListener("click", function(event) {
                event.preventDefault();
                fetch('./historyPage.php')
                    .then(response => response.text())
                    .then(data => {
                        document.getElementById("Main-content").innerHTML = data;
                        setActiveLink(this);
                    })
                    .catch(error => console.error('Error fetching content:', error));
            });

            document.getElementById("Reservation").addEventListener("click", function(event) {
                event.preventDefault();
                fetch('./reservationPage.php')
                    .then(response => response.text())
                    .then(data => {
                        document.getElementById("Main-content").innerHTML = data;
                        setActiveLink(this);
                    })
                    .catch(error => console.error('Error fetching content:', error));
            });
        });
        function openPopup() {
        let popup = document.getElementById("editPopup");
        if (popup) {
            popup.classList.add("show");
        }
    }

    function closePopup() {
        let popup = document.getElementById("editPopup");
        if (popup) {
            popup.classList.remove("show");
            window.location.href = "dashboard.php";
        }
    }

    
    <?php if (isset($_SESSION['success_message'])): ?>
        alert("<?php echo $_SESSION['success_message']; ?>");
        window.location.href = "dashboard.php"; // Redirect back to profile
    <?php unset($_SESSION['success_message']); endif; ?>
    </script>
</body>
</html>


